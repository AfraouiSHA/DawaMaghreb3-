import {
  Component,
  OnInit,
  ViewChild,
  ElementRef,
  AfterViewInit,
  HostListener,
  OnDestroy,
} from "@angular/core"
import { CommonModule, DatePipe } from "@angular/common"
import { FormsModule } from "@angular/forms"
import { HttpClient } from "@angular/common/http"
import { removeBackground } from "@imgly/background-removal"
import { PdfViewerModule, PDFDocumentProxy } from "ng2-pdf-viewer"
import { PDFDocument, degrees, rgb, StandardFonts } from "pdf-lib"
import { saveAs } from "file-saver"

import { SupabaseService } from "src/app/services/supabase.service"

// Angular Material imports
import { MatButtonModule } from "@angular/material/button"
import { MatIconModule } from "@angular/material/icon"
import { MatInputModule } from "@angular/material/input"
import { MatFormFieldModule } from "@angular/material/form-field"
import { MatDatepickerModule } from "@angular/material/datepicker"
import { MatNativeDateModule } from "@angular/material/core"
import { MatRadioModule } from "@angular/material/radio"
import { MatSnackBarModule, MatSnackBar } from "@angular/material/snack-bar"
import { MatProgressSpinnerModule } from "@angular/material/progress-spinner"
import { MatCheckboxModule } from "@angular/material/checkbox"
import { MatSelectModule } from "@angular/material/select"
import { MatButtonToggleModule } from "@angular/material/button-toggle"
import { MatTooltipModule } from "@angular/material/tooltip"
import { MatOptionModule } from "@angular/material/core"
import { MatSliderModule } from "@angular/material/slider"

interface SignatureElement {
  id: string
  x: number // Position X dans le visualiseur (pixels)
  y: number // Position Y dans le visualiseur (pixels)
  width: number // Largeur dans le visualiseur (pixels)
  height: number // Hauteur dans le visualiseur (pixels)
  pdfX: number // Position X dans le PDF (points)
  pdfY: number // Position Y dans le PDF (points)
  pdfWidth: number // Largeur dans le PDF (points)
  pdfHeight: number // Hauteur dans le PDF (points)
  imageDataUrl: string
  page: number
  selected: boolean
  rotation: number
  opacity: number
  aspectRatio: number
}

interface AuditEntry {
  timestamp: Date
  action: string
  details?: any
  isError?: boolean
}

interface Signataire {
  nom: string
  email: string
  fonction: string
  signe: boolean
  dateSignature?: string
  signatureImage?: string
}

interface SignaturePreset {
  name: string
  width: number
  height: number
  description: string
}

interface HistoryState {
  signatureElement: SignatureElement | null
  action: string
  timestamp: Date
}

// Interface pour les dimensions PDF simplifiées
interface SimplePdfDimensions {
  pdfWidth: number // Largeur native du PDF en points
  pdfHeight: number // Hauteur native du PDF en points
  viewerWidth: number // Largeur du visualiseur (canvas) en pixels
  viewerHeight: number // Hauteur du visualiseur (canvas) en pixels
  scaleX: number // Échelle de conversion des pixels du visualiseur en points PDF (X)
  scaleY: number // Échelle de conversion des pixels du visualiseur en points PDF (Y)
  offsetX: number // Décalage X du contenu PDF rendu dans le visualiseur (centrage)
  offsetY: number // Décalage Y du contenu PDF rendu dans le visualiseur (centrage)
}

@Component({
  selector: "app-signature-electronique",
  templateUrl: "./signature-electronique.component.html",
  styleUrls: ["./signature-electronique.component.css"],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    PdfViewerModule,
    MatButtonModule,
    MatIconModule,
    MatInputModule,
    MatFormFieldModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatRadioModule,
    MatSnackBarModule,
    MatProgressSpinnerModule,
    MatCheckboxModule,
    MatSelectModule,
    MatButtonToggleModule,
    MatTooltipModule,
    MatOptionModule,
    MatSliderModule,
    DatePipe,
  ],
  providers: [DatePipe, MatSnackBar],
})
export class SignatureElectroniqueComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild("pdfContainer") pdfContainer!: ElementRef
  @ViewChild("pdfViewerComp", { static: false }) pdfViewerComp: any

  public Math = Math

  pdfSrc: Uint8Array | undefined = undefined
  fileName = "Aucun fichier choisi"
  processedSignatureUrl: string | null = null
  signatureElement: SignatureElement | null = null
  isSignatureConfirmed = false
  isDocumentLocked = false

  isDragging = false
  isResizing = false
  isPlacingSignature = false
  resizeHandle: string | null = null
  placementMode: "click" | "draw" | "preset" = "click"

  initialMouseX = 0
  initialMouseY = 0
  initialSignatureX = 0
  initialSignatureY = 0
  initialSignatureWidth = 0
  initialSignatureHeight = 0

  private pdfViewer: HTMLCanvasElement | null = null
  private pdfDocProxy: PDFDocumentProxy | null = null
  public pdfDimensions: SimplePdfDimensions | null = null

  // Corrections globales ajustables
  public globalOffsetX = 0 // Décalage horizontal global (ajustable)
  public globalOffsetY = 0 // Décalage vertical global (ajustable)

  showGrid = false
  snapToGrid = true
  gridSize = 10
  showGuides = true

  previewSignature: SignatureElement | null = null

  totalPages = 0
  currentPage = 1

  isLoadingPdf = false
  isProcessingSignature = false
  showSignaturePreview = false
  showPropertiesPanel = false

  acceptConditions = false

  signaturePresets: SignaturePreset[] = [
    { name: "Petit", width: 100, height: 40, description: "Signature compacte" },
    { name: "Moyen", width: 150, height: 60, description: "Taille standard" },
    { name: "Grand", width: 200, height: 80, description: "Signature proéminente" },
    { name: "Extra Large", width: 250, height: 100, description: "Signature de titre" },
  ]
  selectedPreset: SignaturePreset = this.signaturePresets[1]

  history: HistoryState[] = []
  historyIndex = -1
  maxHistorySize = 20

  auditEntries: AuditEntry[] = []
  utilisateur = {
    nom: "Utilisateur Test",
    fonction: "Chef de projet",
    email: "test@example.com",
  }

  document = {
    titre: "PV de Commission",
    dateCreation: new Date(),
    referenceInterne: "REF-12345",
    nombreSignataires: 3,
  }
  signataires: Signataire[] = []

  private originalPdfData: Uint8Array | null = null

  // Mode de calibration
  isCalibrationMode = false
  calibrationPoint: { x: number; y: number } | null = null
  referencePoints: Array<{ viewerX: number; viewerY: number; pdfX: number; pdfY: number; label: string }> = []

  // Corrections calculées automatiquement
  calculatedOffsetX = 0
  calculatedOffsetY = 0

  // Propriété calculée pour la glissière d'opacité
  get opacitySliderValue(): number {
    // La glissière doit afficher une valeur entre 0 et 100
    // L'opacité est une valeur entre 0 et 1
    return this.signatureElement ? this.signatureElement.opacity * 100 : 100
  }

  set opacitySliderValue(value: number) {
    if (this.signatureElement && value !== null) {
      // Met à jour l'opacité en divisant par 100
      this.signatureElement.opacity = value / 100
    }
  }

  constructor(
    private http: HttpClient,
    private supabaseService: SupabaseService,
    private datePipe: DatePipe,
    private snackBar: MatSnackBar,
  ) {}

  ngOnInit(): void {
    this.addAuditEntry("Application initialisée")
    this.signataires = [
      { nom: "Alice Dupont", email: "alice@example.com", fonction: "Directrice", signe: false },
      {
        nom: "Bob Martin",
        email: "bob@example.com",
        fonction: "Manager",
        signe: true,
        dateSignature: new Date().toISOString(),
      },
    ]
  }

  ngAfterViewInit(): void {
    document.addEventListener("mousemove", this.onGlobalMouseMove.bind(this))
    document.addEventListener("mouseup", this.onGlobalMouseUp.bind(this))

    setTimeout(() => {
      this.pdfViewer = this.findPdfCanvasElement()
    }, 500)
  }

  ngOnDestroy(): void {
    document.removeEventListener("mousemove", this.onGlobalMouseMove.bind(this))
    document.removeEventListener("mouseup", this.onGlobalMouseUp.bind(this))
  }

  /**
   * Calcule les dimensions réelles du PDF et du visualiseur pour la conversion de coordonnées.
   */
  public async calculateSimpleDimensions(): Promise<void> {
    if (!this.pdfDocProxy || !this.pdfViewer) {
      console.warn("calculateSimpleDimensions: Données manquantes (pdfDocProxy ou pdfViewer)")
      return
    }

    try {
      // Obtenir les dimensions natives de la page PDF
      const page = await this.pdfDocProxy.getPage(this.currentPage)
      const viewport = page.getViewport({ scale: 1 }) // Échelle 1 pour obtenir les dimensions natives

      // Dimensions natives du PDF en points (1/72 pouce)
      const pdfWidth = viewport.width
      const pdfHeight = viewport.height

      // Dimensions du visualiseur (l'élément canvas) en pixels
      const viewerWidth = this.pdfViewer.offsetWidth
      const viewerHeight = this.pdfViewer.offsetHeight

      // Calculer l'échelle de rendu réelle du PDF dans le visualiseur
      // C'est l'échelle par laquelle les dimensions natives du PDF sont multipliées
      // pour s'adapter au `pdf-viewer` lorsque `original-size` est `false`.
      const scaleFactorX = viewerWidth / pdfWidth;
      const scaleFactorY = viewerHeight / pdfHeight;
      const actualRenderScale = Math.min(scaleFactorX, scaleFactorY); // Le PDF est mis à l'échelle pour s'adapter

      // Dimensions du contenu PDF tel qu'il est réellement rendu dans le visualiseur
      const renderedPdfWidth = pdfWidth * actualRenderScale;
      const renderedPdfHeight = pdfHeight * actualRenderScale;

      // Calcul des marges (décalage) si le PDF est centré dans le visualiseur
      const offsetX = (viewerWidth - renderedPdfWidth) / 2;
      const offsetY = (viewerHeight - renderedPdfHeight) / 2;

      this.pdfDimensions = {
        pdfWidth,
        pdfHeight,
        viewerWidth,
        viewerHeight,
        // scaleX et scaleY ici sont l'inverse de l'échelle de rendu,
        // c'est-à-dire le facteur pour convertir des pixels du viewer en points PDF.
        scaleX: pdfWidth / renderedPdfWidth,
        scaleY: pdfHeight / renderedPdfHeight,
        offsetX,
        offsetY,
      }

      this.addAuditEntry("Dimensions PDF calculées", {
        pdfDimensions: this.pdfDimensions,
      })
    } catch (error) {
      console.error("Erreur lors du calcul des dimensions:", error)
      this.addAuditEntry("Erreur calcul dimensions", error, true)
    }
  }

  /**
   * Convertit les coordonnées et dimensions d'un élément du visualiseur (pixels)
   * en coordonnées et dimensions correspondantes dans le PDF (points).
   */
  public convertViewerToPdfCoords(
    viewerX: number,
    viewerY: number,
    viewerWidth: number,
    viewerHeight: number
  ): { pdfX: number; pdfY: number; pdfWidth: number; pdfHeight: number } {
    if (!this.pdfDimensions) {
      console.warn("convertViewerToPdfCoords: Dimensions PDF non disponibles. Retourne 0.")
      return { pdfX: 0, pdfY: 0, pdfWidth: 0, pdfHeight: 0 }
    }

    const { pdfWidth, pdfHeight, offsetX, offsetY, scaleX, scaleY } = this.pdfDimensions;

    // 1. Ajuster les coordonnées du visualiseur en tenant compte du décalage (centrage)
    //    et des décalages globaux manuels et calculés par calibration.
    const adjustedX = viewerX - offsetX + this.globalOffsetX + this.calculatedOffsetX;
    const adjustedY = viewerY - offsetY + this.globalOffsetY + this.calculatedOffsetY;

    // 2. Convertir les pixels du visualiseur en points du PDF
    const pdfX = adjustedX * scaleX;
    
    // 3. Inverser l'axe Y car l'origine du PDF est en bas à gauche,
    //    tandis que le DOM est en haut à gauche.
    //    On soustrait la hauteur de l'élément signature convertie en points PDF
    //    pour que le point Y corresponde au coin inférieur gauche de l'élément.
    const pdfY = pdfHeight - (adjustedY * scaleY) - (viewerHeight * scaleY);
    
    // 4. Convertir les dimensions de la signature en points du PDF
    const pdfW = viewerWidth * scaleX;
    const pdfH = viewerHeight * scaleY;

    return { 
      pdfX: pdfX, 
      pdfY: pdfY, 
      pdfWidth: pdfW, 
      pdfHeight: pdfH 
    };
  }

  private safeArrayBufferCopy(buffer: ArrayBuffer): ArrayBuffer {
    const copy = new ArrayBuffer(buffer.byteLength)
    new Uint8Array(copy).set(new Uint8Array(buffer))
    return copy
  }

  addAuditEntry(action: string, details?: any, isError = false): void {
    let formattedDetails = details
    if (isError && typeof details === "object" && details !== null) {
      formattedDetails = details.message || JSON.stringify(details)
    } else if (details === undefined) {
      formattedDetails = null
    }

    this.auditEntries.unshift({
      timestamp: new Date(),
      action: action,
      details: formattedDetails,
      isError: isError,
    })
    if (this.auditEntries.length > 50) {
      this.auditEntries.pop()
    }
    if (isError) {
      console.error("Audit Error:", action, formattedDetails)
    } else {
      console.log("Audit:", action, formattedDetails || "")
    }
  }

  saveToHistory(action: string): void {
    if (this.historyIndex < this.history.length - 1) {
      this.history = this.history.slice(0, this.historyIndex + 1)
    }
    this.history.push({
      signatureElement: this.signatureElement ? { ...this.signatureElement } : null,
      action: action,
      timestamp: new Date(),
    })
    if (this.history.length > this.maxHistorySize) {
      this.history.shift()
    } else {
      this.historyIndex++
    }
    this.addAuditEntry(`History saved: ${action}`)
  }

  undo(): void {
    if (this.historyIndex > 0) {
      this.historyIndex--
      const state = this.history[this.historyIndex]
      this.signatureElement = state.signatureElement ? { ...state.signatureElement } : null
      this.addAuditEntry(`Annulation: ${state.action}`)
    } else if (this.historyIndex === 0) {
      this.historyIndex--
      this.signatureElement = null
      this.addAuditEntry("Annulation à l'état initial (signature effacée)")
    }
  }

  redo(): void {
    if (this.historyIndex < this.history.length - 1) {
      this.historyIndex++
      const state = this.history[this.historyIndex]
      this.signatureElement = state.signatureElement ? { ...state.signatureElement } : null
      this.addAuditEntry(`Rétablissement: ${state.action}`)
    }
  }

  canUndo(): boolean {
    return this.historyIndex > -1
  }

  canRedo(): boolean {
    return this.historyIndex < this.history.length - 1
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement
    const file = input.files?.[0]
    if (file) {
      if (file.type !== "application/pdf") {
        this.snackBar.open("Veuillez sélectionner un fichier PDF valide.", "Fermer", {
          duration: 3000,
          panelClass: ["error-snackbar"],
        })
        this.addAuditEntry("Erreur: Type de fichier invalide", { type: file.type }, true)
        return
      }
      this.fileName = file.name
      this.isLoadingPdf = true
      const reader = new FileReader()
      reader.onload = (e: ProgressEvent<FileReader>) => {
        if (e.target?.result) {
          try {
            const arrayBuffer = e.target.result as ArrayBuffer
            if (arrayBuffer.byteLength === 0) {
              throw new Error("Le fichier PDF est vide")
            }

            const uint8Array = new Uint8Array(arrayBuffer.byteLength)
            const sourceView = new Uint8Array(arrayBuffer)

            for (let i = 0; i < arrayBuffer.byteLength; i++) {
              uint8Array[i] = sourceView[i]
            }

            const header = new TextDecoder().decode(uint8Array.slice(0, 5))
            if (!header.startsWith("%PDF")) {
              throw new Error("Le fichier ne semble pas être un PDF valide")
            }

            this.originalPdfData = uint8Array
            this.pdfSrc = new Uint8Array(uint8Array)

            this.addAuditEntry("Fichier PDF sélectionné et validé", {
              fileName: this.fileName,
              size: uint8Array.length,
            })

            console.log("PDF loaded and stored, size:", uint8Array.length)
          } catch (error) {
            this.isLoadingPdf = false
            const errorMessage = error instanceof Error ? error.message : "Erreur inconnue"
            this.addAuditEntry("Erreur lors de la validation du PDF", { error: errorMessage }, true)
            this.snackBar.open(`Erreur lors du chargement du PDF: ${errorMessage}`, "Fermer", {
              duration: 5000,
              panelClass: ["error-snackbar"],
            })
          }
        }
      }
      reader.onerror = () => {
        this.isLoadingPdf = false
        this.addAuditEntry("Erreur de lecture du fichier", null, true)
        this.snackBar.open("Erreur lors de la lecture du fichier", "Fermer", {
          duration: 5000,
          panelClass: ["error-snackbar"],
        })
      }
      reader.readAsArrayBuffer(file)
    } else {
      this.fileName = "Aucun fichier choisi"
      this.pdfSrc = undefined
      this.originalPdfData = null
      this.addAuditEntry("Sélection de fichier annulée")
    }
  }

  public async onPdfLoadComplete(pdf: PDFDocumentProxy): Promise<void> {
    this.pdfDocProxy = pdf
    this.totalPages = pdf.numPages
    this.addAuditEntry("PDF chargé avec succès", { pages: this.totalPages })
    console.log("onPdfLoadComplete: PDF chargé, pages:", this.totalPages)

    // Attendre que le DOM soit stable
    setTimeout(async () => {
      this.pdfViewer = this.findPdfCanvasElement()
      if (this.pdfViewer) {
        console.log("onPdfLoadComplete: pdfViewer (canvas) trouvé")

        // Calculer les dimensions simplifiées
        await this.calculateSimpleDimensions()

        this.addAuditEntry("PDF viewer initialisé", {
          canvasSize: { width: this.pdfViewer.offsetWidth, height: this.pdfViewer.offsetHeight },
          pdfDimensions: this.pdfDimensions,
        })
      } else {
        console.error("onPdfLoadComplete: Impossible de trouver l'élément canvas")
        this.snackBar.open("Erreur: Impossible de détecter le visualiseur PDF.", "Fermer", {
          duration: 7000,
          panelClass: ["error-snackbar"],
        })
      }
      this.isLoadingPdf = false
    }, 1000)
  }

  private findPdfCanvasElement(): HTMLCanvasElement | null {
    console.log("findPdfCanvasElement: Recherche du canvas PDF...")
    if (this.pdfContainer?.nativeElement) {
      const pdfViewerHost = this.pdfContainer.nativeElement.querySelector("pdf-viewer")
      if (pdfViewerHost) {
        const canvas = pdfViewerHost.querySelector("canvas")
        if (canvas instanceof HTMLCanvasElement && canvas.offsetWidth > 0 && canvas.offsetHeight > 0) {
          console.log("findPdfCanvasElement: Canvas trouvé avec dimensions valides")
          return canvas
        }
      }
    }
    console.error("findPdfCanvasElement: Canvas non trouvé")
    return null
  }

  public async onSignatureFileSelected(event: Event): Promise<void> {
    const input = event.target as HTMLInputElement
    const file = input.files?.[0]
    if (file) {
      this.isProcessingSignature = true
      this.snackBar.open("Traitement de la signature (suppression du fond)...", "Fermer", {
        duration: 0,
        panelClass: ["info-snackbar"],
      })
      this.addAuditEntry("Début du traitement de la signature pour supprimer le fond.")
      try {
        const resultBlob = await removeBackground(file)
        const reader = new FileReader()
        reader.onload = (e) => {
          this.processedSignatureUrl = e.target?.result as string
          this.signatureElement = null
          this.addAuditEntry("Signature traitée et prête à être placée.", { fileName: file.name })
          this.isProcessingSignature = false
          this.snackBar.open("Signature traitée avec succès !", "Fermer", {
            duration: 3000,
            panelClass: ["success-snackbar"],
          })
          this.setPlacementMode("click")
        }
        reader.readAsDataURL(resultBlob)
      } catch (error) {
        console.error("Erreur lors de la suppression du fond:", error)
        this.addAuditEntry("Erreur lors de la suppression du fond.", { error: error }, true)
        this.isProcessingSignature = false
        this.snackBar.open("Erreur lors du traitement de la signature. Veuillez réessayer.", "Fermer", {
          duration: 5000,
          panelClass: ["error-snackbar"],
        })
      }
    } else {
      this.processedSignatureUrl = null
      this.addAuditEntry("Sélection de signature annulée")
    }
  }

  setPlacementMode(mode: "click" | "draw" | "preset"): void {
    if (!this.processedSignatureUrl) {
      this.snackBar.open("Veuillez d'abord télécharger une signature pour l'utiliser.", "Fermer", {
        duration: 3000,
        panelClass: ["error-snackbar"],
      })
      return
    }
    this.placementMode = mode
    this.isPlacingSignature = true
    this.previewSignature = null
    if (this.pdfContainer?.nativeElement) {
      const container = this.pdfContainer.nativeElement
      container.style.cursor = "copy"
    }
    this.addAuditEntry(`Mode de placement activé: ${mode}`)
    this.snackBar.open(`Mode de placement: Cliquez sur le PDF pour placer la signature.`, "Fermer", {
      duration: 4000,
      panelClass: ["info-snackbar"],
    })
  }

  cancelPlacement(): void {
    this.isPlacingSignature = false
    this.previewSignature = null
    this.placementMode = "click"
    if (this.pdfContainer?.nativeElement) {
      this.pdfContainer.nativeElement.style.cursor = "default"
    }
    this.addAuditEntry("Placement de signature annulé")
    this.snackBar.open("Placement de signature annulé.", "Fermer", { duration: 2000 })
  }

  public onPdfClick(event: MouseEvent): void {
    const { x, y } = this.getRelativePosition(event)

    // Gérer le mode calibration
    if (this.isCalibrationMode) {
      this.calibrationPoint = { x, y }

      // Ouvrir un dialog pour demander les coordonnées PDF attendues
      const expectedX = prompt("Entrez la coordonnée X attendue dans le PDF (en points):")
      const expectedY = prompt("Entrez la coordonnée Y attendue dans le PDF (en points):")

      if (expectedX !== null && expectedY !== null) {
        const pdfX = Number.parseFloat(expectedX)
        const pdfY = Number.parseFloat(expectedY)

        if (!isNaN(pdfX) && !isNaN(pdfY)) {
          this.calibrateWithPoint(x, y, pdfX, pdfY)
          this.cancelCalibrationMode()
          return
        }
      }

      this.cancelCalibrationMode()
      return
    }

    // Logique existante pour placer la signature
    if (!this.isPlacingSignature || !this.processedSignatureUrl) {
      return
    }

    if (!this.pdfViewer || !this.pdfDimensions) {
      console.error("onPdfClick: Visualiseur PDF ou dimensions non disponibles")
      this.snackBar.open("Erreur: Le visualiseur PDF n'est pas prêt.", "Fermer", {
        duration: 5000,
        panelClass: ["error-snackbar"],
      })
      return
    }

    this.signatureElement = {
      id: `sig-${Date.now()}`,
      x: x - this.selectedPreset.width / 2,
      y: y - this.selectedPreset.height / 2,
      width: this.selectedPreset.width,
      height: this.selectedPreset.height,
      imageDataUrl: this.processedSignatureUrl,
      page: this.currentPage,
      selected: true,
      rotation: 0,
      opacity: 1,
      aspectRatio: this.selectedPreset.width / this.selectedPreset.height,
      pdfX: 0,
      pdfY: 0,
      pdfWidth: 0,
      pdfHeight: 0,
    }

    this.updateSignaturePdfCoordinates()
    this.saveToHistory("Placement de signature")

    this.addAuditEntry("Signature placée", {
      x: this.signatureElement.x,
      y: this.signatureElement.y,
      page: this.currentPage,
      calibrationStatus: this.getCalibrationStatus(),
    })

    this.isPlacingSignature = false
    this.previewSignature = null
    this.showPropertiesPanel = true

    this.snackBar.open("Signature placée ! Utilisez les contrôles pour ajuster si nécessaire.", "Fermer", {
      duration: 3000,
      panelClass: ["success-snackbar"],
    })
  }

  public getRelativePosition(event: MouseEvent): { x: number; y: number } {
    if (!this.pdfViewer) {
      console.warn("getRelativePosition: pdfViewer non disponible")
      return { x: 0, y: 0 }
    }

    const pdfViewerRect = this.pdfViewer.getBoundingClientRect()
    const x = event.clientX - pdfViewerRect.left
    const y = event.clientY - pdfViewerRect.top
    return { x, y }
  }

  public updateSignaturePdfCoordinates(): void {
    if (!this.signatureElement) {
      console.warn("updateSignaturePdfCoordinates: Signature non disponible")
      return
    }

    const convertedCoords = this.convertViewerToPdfCoords(
      this.signatureElement.x,
      this.signatureElement.y,
      this.signatureElement.width,
      this.signatureElement.height,
    )

    this.signatureElement.pdfX = convertedCoords.pdfX
    this.signatureElement.pdfY = convertedCoords.pdfY
    this.signatureElement.pdfWidth = convertedCoords.pdfWidth
    this.signatureElement.pdfHeight = convertedCoords.pdfHeight

    console.log("Coordonnées PDF mises à jour:", convertedCoords)
  }

  /**
   * Ajuster le décalage horizontal global
   */
  adjustGlobalOffsetX(delta: number): void {
    this.globalOffsetX += delta
    if (this.signatureElement) {
      this.updateSignaturePdfCoordinates()
    }
    this.addAuditEntry(`Décalage horizontal global ajusté: ${this.globalOffsetX}`)
    this.snackBar.open(`Décalage horizontal: ${this.globalOffsetX} points`, "Fermer", {
      duration: 1000,
    })
  }

  /**
   * Ajuster le décalage vertical global
   */
  adjustGlobalOffsetY(delta: number): void {
    this.globalOffsetY += delta
    if (this.signatureElement) {
      this.updateSignaturePdfCoordinates()
    }
    this.addAuditEntry(`Décalage vertical global ajusté: ${this.globalOffsetY}`)
    this.snackBar.open(`Décalage vertical: ${this.globalOffsetY} points`, "Fermer", {
      duration: 1000,
    })
  }

  /**
   * Réinitialiser les décalages globaux
   */
  resetGlobalOffsets(): void {
    this.globalOffsetX = 0 
    this.globalOffsetY = 0
    if (this.signatureElement) {
      this.updateSignaturePdfCoordinates()
    }
    this.addAuditEntry("Décalages globaux réinitialisés")
    this.snackBar.open("Décalages réinitialisés", "Fermer", { duration: 2000 })
  }

  applyPreset(preset: SignaturePreset): void {
    if (this.signatureElement) {
      this.saveToHistory("Application de preset")
      this.signatureElement.width = preset.width
      this.signatureElement.height = preset.height
      this.signatureElement.aspectRatio = preset.width / preset.height
      this.updateSignaturePdfCoordinates()
      this.addAuditEntry(`Preset appliqué: ${preset.name}`, {
        width: this.signatureElement.width,
        height: this.signatureElement.height,
      })
    }
  }

  startDraggingSignature(event: MouseEvent): void {
    if (!this.signatureElement) return
    this.isDragging = true
    this.initialMouseX = event.clientX
    this.initialMouseY = event.clientY
    this.initialSignatureX = this.signatureElement.x
    this.initialSignatureY = this.signatureElement.y
    this.addAuditEntry("Début du déplacement de la signature")
    event.stopPropagation()
  }

  startResizingSignature(event: MouseEvent, handle: string): void {
    if (!this.signatureElement) return
    event.stopPropagation()
    this.isResizing = true
    this.resizeHandle = handle
    this.initialMouseX = event.clientX
    this.initialMouseY = event.clientY
    this.initialSignatureX = this.signatureElement.x
    this.initialSignatureY = this.signatureElement.y
    this.initialSignatureWidth = this.signatureElement.width
    this.initialSignatureHeight = this.signatureElement.height
    this.addAuditEntry(`Début du redimensionnement (${handle})`)
  }

  @HostListener("document:mousemove", ["$event"])
  onGlobalMouseMove(event: MouseEvent): void {
    if (this.isPlacingSignature) {
      this.onPdfMouseMove(event)
    } else if (this.isDragging) {
      this.onSignatureDrag(event)
    } else if (this.isResizing) {
      this.onSignatureResize(event)
    }
  }

  @HostListener("document:mouseup")
  onGlobalMouseUp(): void {
    if (this.isDragging || this.isResizing) {
      this.saveToHistory(this.isDragging ? "Déplacement de signature" : "Redimensionnement de signature")
      this.updateSignaturePdfCoordinates()
    }

    const wasInteracting = this.isDragging || this.isResizing
    this.isDragging = false
    this.isResizing = false
    this.resizeHandle = null

    if (wasInteracting && this.signatureElement) {
      this.addAuditEntry("Fin de l'interaction avec la signature", {
        signatureId: this.signatureElement.id,
        position: {
          x: this.signatureElement.x,
          y: this.signatureElement.y,
          pdfX: this.signatureElement.pdfX,
          pdfY: this.signatureElement.pdfY,
        },
      })
    }
  }

  onPdfMouseMove(event: MouseEvent): void {
    if (!this.isPlacingSignature || !this.processedSignatureUrl) {
      this.previewSignature = null
      return
    }

    if (!this.pdfViewer) {
      this.previewSignature = null
      return
    }

    const { x, y } = this.getRelativePosition(event)

    this.previewSignature = {
      id: "preview",
      x: x - this.selectedPreset.width / 2,
      y: y - this.selectedPreset.height / 2,
      width: this.selectedPreset.width,
      height: this.selectedPreset.height,
      imageDataUrl: this.processedSignatureUrl,
      page: this.currentPage,
      selected: false,
      rotation: 0,
      opacity: 0.7,
      aspectRatio: this.selectedPreset.width / this.selectedPreset.height,
      pdfX: 0,
      pdfY: 0,
      pdfWidth: 0,
      pdfHeight: 0,
    }
  }

  onSignatureDrag(event: MouseEvent): void {
    if (!this.isDragging || !this.signatureElement) return

    const dx = event.clientX - this.initialMouseX
    const dy = event.clientY - this.initialMouseY

    const newX = this.snapToGrid
      ? Math.round((this.initialSignatureX + dx) / this.gridSize) * this.gridSize
      : this.initialSignatureX + dx
    const newY = this.snapToGrid
      ? Math.round((this.initialSignatureY + dy) / this.gridSize) * this.gridSize
      : this.initialSignatureY + dy

    this.signatureElement.x = newX
    this.signatureElement.y = newY
  }

  onSignatureResize(event: MouseEvent): void {
    if (!this.isResizing || !this.signatureElement || !this.resizeHandle) return

    const dx = event.clientX - this.initialMouseX
    const dy = event.clientY - this.initialMouseY

    let newWidth = this.initialSignatureWidth
    let newHeight = this.initialSignatureHeight
    let newX = this.initialSignatureX
    let newY = this.initialSignatureY

    const aspectRatio = this.signatureElement.aspectRatio

    switch (this.resizeHandle) {
      case "br":
        newWidth = this.initialSignatureWidth + dx
        newHeight = this.initialSignatureHeight + dy
        break
      case "bl":
        newWidth = this.initialSignatureWidth - dx
        newHeight = this.initialSignatureHeight + dy
        newX = this.initialSignatureX + dx
        break
      case "tr":
        newWidth = this.initialSignatureWidth + dx
        newHeight = this.initialSignatureHeight - dy
        newY = this.initialSignatureY + dy
        break
      case "tl":
        newWidth = this.initialSignatureWidth - dx
        newHeight = this.initialSignatureHeight - dy
        newX = this.initialSignatureX + dx
        newY = this.initialSignatureY + dy
        break
    }

    if (newWidth > 20 && newHeight > 20) {
      if (Math.abs(dx) > Math.abs(dy)) {
        newHeight = newWidth / aspectRatio
      } else {
        newWidth = newHeight * aspectRatio
      }
    }

    if (newWidth < 20) newWidth = 20
    if (newHeight < 20) newHeight = 20

    if (this.snapToGrid) {
      newWidth = Math.round(newWidth / this.gridSize) * this.gridSize
      newHeight = Math.round(newHeight / this.gridSize) * this.gridSize
      newX = Math.round(newX / this.gridSize) * this.gridSize
      newY = Math.round(newY / this.gridSize) * this.gridSize
    }

    this.signatureElement.x = newX
    this.signatureElement.y = newY
    this.signatureElement.width = newWidth
    this.signatureElement.height = newHeight
  }

  public async goToPage(newPage: number): Promise<void> {
    if (newPage >= 1 && newPage <= this.totalPages) {
      this.currentPage = newPage
      this.addAuditEntry("Navigation de page", { page: this.currentPage })

      // Recalculer les dimensions pour la nouvelle page
      setTimeout(async () => {
        await this.calculateSimpleDimensions()
        if (this.signatureElement) {
          this.updateSignaturePdfCoordinates()
        }
      }, 500)
    }
  }

  confirmerSignature(): void {
    if (this.signatureElement) {
      this.isSignatureConfirmed = true
      this.addAuditEntry("Signature confirmée", {
        id: this.signatureElement.id,
        globalOffsets: { x: this.globalOffsetX, y: this.globalOffsetY },
      })
      this.snackBar.open("Signature confirmée !", "Fermer", {
        duration: 2000,
        panelClass: ["success-snackbar"],
      })
    }
  }

  async applySignatureAndSavePdf(): Promise<void> {
    if (!this.pdfViewer || !this.pdfDimensions) {
      this.snackBar.open("Erreur: Le visualiseur PDF n'est pas prêt.", "Fermer", {
        duration: 5000,
        panelClass: ["error-snackbar"],
      })
      return
    }

    if (!this.originalPdfData || !this.signatureElement || !this.processedSignatureUrl) {
      this.snackBar.open("Données manquantes pour la finalisation.", "Fermer", {
        duration: 5000,
        panelClass: ["error-snackbar"],
      })
      return
    }

    try {
      this.isProcessingSignature = true
      this.snackBar.open("Application de la signature et sauvegarde du document...", "Fermer", {
        duration: 0,
        panelClass: ["info-snackbar"],
      })

      this.addAuditEntry("Début de l'application de la signature au PDF", {
        coordinates: {
          pdfX: this.signatureElement.pdfX,
          pdfY: this.signatureElement.pdfY,
          pdfWidth: this.signatureElement.pdfWidth,
          pdfHeight: this.signatureElement.pdfHeight,
        },
        globalOffsets: { x: this.globalOffsetX, y: this.globalOffsetY },
      })

      const pdfBuffer = this.originalPdfData.slice(0)
      const pdfDoc = await PDFDocument.load(pdfBuffer)
      const pages = pdfDoc.getPages()
      const pageIndex = this.signatureElement.page - 1
      const targetPage = pages[pageIndex]

      if (!targetPage) {
        throw new Error(`Page cible du PDF introuvable (page ${this.signatureElement.page}).`)
      }

      const response = await fetch(this.processedSignatureUrl)
      if (!response.ok) {
        throw new Error(`Erreur de chargement de la signature: ${response.statusText}`)
      }

      const pngImageBytes = await response.arrayBuffer()
      const signatureImage = await pdfDoc.embedPng(pngImageBytes)

      // **APPLICATION FINALE DE LA SIGNATURE**
      targetPage.drawImage(signatureImage, {
        x: this.signatureElement.pdfX,
        y: this.signatureElement.pdfY,
        width: this.signatureElement.pdfWidth,
        height: this.signatureElement.pdfHeight,
        rotate: degrees(this.signatureElement.rotation),
        opacity: this.signatureElement.opacity,
      })

      // Ajouter métadonnées
      const font = await pdfDoc.embedFont(StandardFonts.Helvetica)
      const auditText = `Signed by ${this.utilisateur.nom} (${this.utilisateur.email}) on ${this.datePipe.transform(new Date(), "medium")} - Global Offsets: X=${this.globalOffsetX}, Y=${this.globalOffsetY}`
      targetPage.drawText(auditText, {
        x: 50,
        y: 20,
        font,
        size: 8,
        color: rgb(0.5, 0.5, 0.5),
      })

      const modifiedPdfBytes = await pdfDoc.save()
      const newFileName = `signé_${this.fileName}`
      saveAs(new Blob([modifiedPdfBytes], { type: "application/pdf" }), newFileName)

      this.addAuditEntry("PDF signé et enregistré avec succès", {
        fileName: newFileName,
        globalOffsets: { x: this.globalOffsetX, y: this.globalOffsetY },
      })

      this.snackBar.open("Document signé et téléchargé avec succès !", "Fermer", {
        duration: 5000,
        panelClass: ["success-snackbar"],
      })

      this.isDocumentLocked = true
      this.isProcessingSignature = false
    } catch (error) {
      console.error("Erreur lors de l'application de la signature au PDF:", error)
      this.addAuditEntry("Erreur lors de la finalisation du PDF", error, true)
      this.isProcessingSignature = false

      let errorMessage = "Une erreur est survenue lors de la finalisation du document."
      if (error instanceof Error) {
        errorMessage += ` Détails: ${error.message}`
      }

      this.snackBar.open(errorMessage, "Fermer", { duration: 5000, panelClass: ["error-snackbar"] })
    }
  }

  alignSignature(alignment: "left" | "center" | "right" | "top" | "middle" | "bottom"): void {
    if (!this.signatureElement || !this.pdfViewer) return

    this.saveToHistory(`Alignment: ${alignment}`)

    const viewerWidth = this.pdfViewer.offsetWidth
    const viewerHeight = this.pdfViewer.offsetHeight

    switch (alignment) {
      case "left":
        this.signatureElement.x = 0
        break
      case "center":
        this.signatureElement.x = (viewerWidth - this.signatureElement.width) / 2
        break
      case "right":
        this.signatureElement.x = viewerWidth - this.signatureElement.width
        break
      case "top":
        this.signatureElement.y = 0
        break
      case "middle":
        this.signatureElement.y = (viewerHeight - this.signatureElement.height) / 2
        break
      case "bottom":
        this.signatureElement.y = viewerHeight - this.signatureElement.height
        break
    }

    this.updateSignaturePdfCoordinates()
    this.addAuditEntry(`Signature alignée: ${alignment}`)
  }

  deleteSignature(): void {
    if (this.signatureElement) {
      this.saveToHistory("Signature supprimée")
      this.signatureElement = null
      this.processedSignatureUrl = null
      this.showPropertiesPanel = false
      this.addAuditEntry("Signature supprimée")
      this.snackBar.open("Signature supprimée avec succès.", "Fermer", {
        duration: 2000,
        panelClass: ["success-snackbar"],
      })
    }
  }

  duplicateSignature(): void {
    if (this.signatureElement && this.signatureElement.imageDataUrl) {
      const duplicate: SignatureElement = {
        ...JSON.parse(JSON.stringify(this.signatureElement)),
        id: `sig-${Date.now()}-dup`,
        x: this.signatureElement.x + 20,
        y: this.signatureElement.y + 20,
        selected: true,
      }
      this.saveToHistory("Signature dupliquée")
      this.signatureElement = duplicate
      this.updateSignaturePdfCoordinates()
      this.addAuditEntry("Signature dupliquée")
      this.snackBar.open("Signature dupliquée.", "Fermer", { duration: 2000, panelClass: ["success-snackbar"] })
    }
  }

  rotateSignature(angle: number): void {
    if (this.signatureElement) {
      this.saveToHistory("Signature tournée")
      this.signatureElement.rotation = ((this.signatureElement.rotation || 0) + angle) % 360
      if (this.signatureElement.rotation < 0) {
        this.signatureElement.rotation += 360
      }
      this.updateSignaturePdfCoordinates()
      this.addAuditEntry(`Signature tournée de ${angle}°`)
    }
  }

  /**
   * MÉTHODES POUR LE TEMPLATE (versions simplifiées)
   */

  getPrecisionStatus(): string {
    return this.pdfDimensions ? "Système calibré" : "Non calibré"
  }

  getPrecisionStatusColor(): string {
    return this.pdfDimensions ? "#4caf50" : "#f44336"
  }

  getCurrentAccuracy(): number {
    return this.pdfDimensions ? 95 : 0
  }

  async recalculateDimensions(): Promise<void> {
    this.snackBar.open("Recalcul des dimensions...", "Fermer", { duration: 2000 })
    await this.calculateSimpleDimensions()
    if (this.signatureElement) {
      this.updateSignaturePdfCoordinates()
    }
    this.snackBar.open("Dimensions recalculées !", "Fermer", {
      duration: 3000,
      panelClass: ["success-snackbar"],
    })
  }

  testPrecisionAtPoint(x: number, y: number): void {
    this.snackBar.open(
      `Test au point (${x.toFixed(0)}, ${y.toFixed(0)}) - Décalages: X=${this.globalOffsetX}, Y=${this.globalOffsetY}`,
      "Fermer",
      {
        duration: 4000,
        panelClass: ["info-snackbar"],
      },
    )
  }

  validateConversion(): number {
    return this.pdfDimensions ? 95 : 0
  }

  /**
   * Activer le mode de calibration
   */
  startCalibrationMode(): void {
    this.isCalibrationMode = true
    this.calibrationPoint = null
    if (this.pdfContainer?.nativeElement) {
      this.pdfContainer.nativeElement.style.cursor = "crosshair"
    }
    this.snackBar.open("Mode calibration activé. Cliquez sur un point de référence connu dans le PDF.", "Fermer", {
      duration: 5000,
      panelClass: ["info-snackbar"],
    })
    this.addAuditEntry("Mode calibration activé")
  }

  /**
   * Calibrer avec un point de référence
   */
  calibrateWithPoint(viewerX: number, viewerY: number, expectedPdfX: number, expectedPdfY: number): void {
    if (!this.pdfDimensions) {
      this.snackBar.open("Erreur: Dimensions PDF non calculées", "Fermer", {
        duration: 3000,
        panelClass: ["error-snackbar"],
      })
      return
    }

    // Calculer où ce point devrait être selon notre conversion actuelle
    const adjustedX = viewerX - this.pdfDimensions.offsetX + this.globalOffsetX
    const adjustedY = viewerY - this.pdfDimensions.offsetY + this.globalOffsetY

    const calculatedPdfX = adjustedX * this.pdfDimensions.scaleX
    let calculatedPdfY = adjustedY * this.pdfDimensions.scaleY
    calculatedPdfY = this.pdfDimensions.pdfHeight - calculatedPdfY

    // Calculer la différence (erreur)
    const errorX = expectedPdfX - calculatedPdfX
    const errorY = expectedPdfY - calculatedPdfY

    // Mettre à jour les corrections calculées
    this.calculatedOffsetX = errorX
    this.calculatedOffsetY = errorY

    // Sauvegarder ce point de référence
    this.referencePoints.push({
      viewerX,
      viewerY,
      pdfX: expectedPdfX,
      pdfY: expectedPdfY,
      label: `Point ${this.referencePoints.length + 1}`,
    })

    this.addAuditEntry("Point de calibration ajouté", {
      viewer: { x: viewerX, y: viewerY },
      expectedPdf: { x: expectedPdfX, y: expectedPdfY },
      calculatedPdf: { x: calculatedPdfX, y: calculatedPdfY },
      corrections: { x: errorX, y: errorY },
    })

    this.snackBar.open(
      `Calibration effectuée ! Corrections: X=${errorX.toFixed(1)}, Y=${errorY.toFixed(1)}`,
      "Fermer",
      {
        duration: 4000,
        panelClass: ["success-snackbar"],
      },
    )

    // Mettre à jour la signature si elle existe
    if (this.signatureElement) {
      this.updateSignaturePdfCoordinates()
    }
  }

  /**
   * Calibration automatique avec des points prédéfinis
   */
  autoCalibrate(): void {
    if (!this.pdfDimensions) {
      this.snackBar.open("Erreur: PDF non chargé", "Fermer", {
        duration: 3000,
        panelClass: ["error-snackbar"],
      })
      return
    }

    // Points de calibration prédéfinis pour un PDF A4 standard
    const standardPoints = [
      { viewerPercent: { x: 0.1, y: 0.1 }, pdfPoints: { x: 50, y: 792 } }, // Coin haut-gauche
      { viewerPercent: { x: 0.9, y: 0.1 }, pdfPoints: { x: 545, y: 792 } }, // Coin haut-droite
      { viewerPercent: { x: 0.5, y: 0.5 }, pdfPoints: { x: 297.5, y: 421 } }, // Centre
    ]

    let totalErrorX = 0
    let totalErrorY = 0
    let validPoints = 0

    for (const point of standardPoints) {
      const viewerX = point.viewerPercent.x * this.pdfDimensions.viewerWidth
      const viewerY = point.viewerPercent.y * this.pdfDimensions.viewerHeight

      const adjustedX = viewerX - this.pdfDimensions.offsetX + this.globalOffsetX
      const adjustedY = viewerY - this.pdfDimensions.offsetY + this.globalOffsetY

      const calculatedPdfX = adjustedX * this.pdfDimensions.scaleX
      let calculatedPdfY = adjustedY * this.pdfDimensions.scaleY
      calculatedPdfY = this.pdfDimensions.pdfHeight - calculatedPdfY

      const errorX = point.pdfPoints.x - calculatedPdfX
      const errorY = point.pdfPoints.y - calculatedPdfY

      totalErrorX += errorX
      totalErrorY += errorY
      validPoints++
    }

    if (validPoints > 0) {
      this.calculatedOffsetX = totalErrorX / validPoints
      this.calculatedOffsetY = totalErrorY / validPoints

      this.addAuditEntry("Calibration automatique effectuée", {
        pointsUsed: validPoints,
        corrections: { x: this.calculatedOffsetX, y: this.calculatedOffsetY },
      })

      this.snackBar.open(
        `Calibration automatique terminée ! Corrections moyennes: X=${this.calculatedOffsetX.toFixed(1)}, Y=${this.calculatedOffsetY.toFixed(1)}`,
        "Fermer",
        {
          duration: 4000,
          panelClass: ["success-snackbar"],
        },
      )

      // Mettre à jour la signature si elle existe
      if (this.signatureElement) {
        this.updateSignaturePdfCoordinates()
      }
    }
  }

  /**
   * Annuler le mode de calibration
   */
  cancelCalibrationMode(): void {
    this.isCalibrationMode = false
    this.calibrationPoint = null
    if (this.pdfContainer?.nativeElement) {
      this.pdfContainer.nativeElement.style.cursor = "default"
    }
    this.addAuditEntry("Mode calibration annulé")
    this.snackBar.open("Mode calibration annulé", "Fermer", { duration: 2000 })
  }

  /**
   * Réinitialiser la calibration
   */
  resetCalibration(): void {
    this.calculatedOffsetX = 0
    this.calculatedOffsetY = 0
    this.referencePoints = []
    if (this.signatureElement) {
      this.updateSignaturePdfCoordinates()
    }
    this.addAuditEntry("Calibration réinitialisée")
    this.snackBar.open("Calibration réinitialisée", "Fermer", { duration: 2000 })
  }

  /**
   * Obtenir le statut de calibration
   */
  getCalibrationStatus(): string {
    if (this.referencePoints.length === 0 && this.calculatedOffsetX === 0 && this.calculatedOffsetY === 0) {
      return "Non calibré"
    }
    return `Calibré (${this.referencePoints.length} points)`
  }

  /**
   * Obtenir la couleur du statut de calibration
   */
  getCalibrationStatusColor(): string {
    if (this.referencePoints.length === 0 && this.calculatedOffsetX === 0 && this.calculatedOffsetY === 0) {
      return "#f44336"
    }
    return this.referencePoints.length > 0 ? "#4caf50" : "#ff9800"
  }

  private handleError(message: string, error?: any): void {
    console.error(message, error)
    this.addAuditEntry(message, error, true)
    
    const errorMessage = error instanceof Error ? `${message}: ${error.message}` : message
    this.snackBar.open(errorMessage, "Fermer", {
      duration: 5000,
      panelClass: ["error-snackbar"],
    })
  }
}